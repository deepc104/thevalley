<?php

namespace Drupal\spark\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Component\Utility\Unicode;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Symfony\Component\HttpFoundation\ResponseHeaderBag;

class FileForceDownloadController extends ControllerBase {

  public function download() {
    global $base_path;
    if (!isset($_GET['url'])) {
      return false;
    }
    $url = \Drupal::request()->query->get('url');
    $uri = DRUPAL_ROOT.urldecode($url);
    $name = basename($uri);
    $response = new BinaryFileResponse($uri);
    $response->setContentDisposition(
        ResponseHeaderBag::DISPOSITION_ATTACHMENT, Unicode::mimeHeaderEncode($name)
    );
    return $response;
  }

}
