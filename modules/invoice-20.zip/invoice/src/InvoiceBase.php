<?php

namespace Drupal\invoice;

class InvoiceBase {
	
	public function getInvoiceId() {
	    $invoice_count = \Drupal::entityQuery('invoice')->count()->execute();
		return $invoice_count+1;
	}

	/*
	p*blic static function generatePdf($invoice, $destination = \Mpdf\Output\Destination::INLINE) {
	    $view_mode = 'pdf';
	    $entity_type = 'invoice';
	    $view_builder = \Drupal::entityTypeManager()->getViewBuilder($entity_type);
	    $build = $view_builder->view($invoice, $view_mode);
	    $output = render($build);

	    $mpdf = new \Mpdf\Mpdf([
	      'tempDir' => 'sites/default/files/tmp',
	      'setAutoTopMargin' => 'pad',
	      'setAutoBottomMargin' => 'stretch',
	      'autoMarginPadding' => 5
	    ]);
	    $mpdf->WriteHTML($output);
	    return $mpdf->Output('invoice-'.$invoice->id() . '.pdf', $destination);
	 }*/

}