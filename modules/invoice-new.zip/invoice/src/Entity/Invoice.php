<?php

namespace Drupal\invoice\Entity;

use Drupal\Core\Entity\EntityStorageInterface;
use Drupal\Core\Field\BaseFieldDefinition;
use Drupal\Core\Entity\ContentEntityBase;
use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\user\UserInterface;
use Drupal\Core\Entity\EntityChangedTrait;
use Drupal\Core\Entity\ContentEntityInterface;

/**
 * Defines the invoice entity.
 *
 * @ingroup invoice
 *
 * @ContentEntityType(
 *   id = "invoice",
 *   label = @Translation("Invoice"),
 *   base_table = "invoice",
 *   entity_keys = {
 *     "id" = "id",
 *     "uuid" = "uuid",
 *     "user_id" = "user_id",
 *     "created" = "created",
 *     "changed" = "changed"
 *   },
 *   fieldable = TRUE,
 *   field_ui_base_route = "invoice.invoice_settings",
 * 	 handlers = {
 * 		"view_builder" = "Drupal\Core\Entity\EntityViewBuilder",
 * 		"list_builder" = "Drupal\invoice\Entity\Controller\InvoiceListBuilder",
 *   	"form" = {
 *     		"add" = "Drupal\invoice\Form\InvoiceForm",
 *     		"edit" = "Drupal\invoice\Form\InvoiceForm",
 *     		"delete" = "Drupal\invoice\Form\InvoiceDeleteForm",
 *   	},
 *   },
 *   admin_permission = "administer invoice entity",
 *   links = {
 *     "canonical" = "/invoice/{invoice}",
 *     "canonical" = "/invoice/add",
 *     "edit-form" = "/invoice/{invoice}/edit",
 *     "delete-form" = "/invoice/{invoice}/delete",
 *     "collection" = "/invoice/list"
 *   },
 * )
 */
 
 class Invoice extends ContentEntityBase implements ContentEntityInterface {
  use EntityChangedTrait;

  protected $id;  

  public static function preCreate(EntityStorageInterface $storage, array &$values) {
	parent::preCreate($storage, $values);
    	$values += array(
          'user_id' => \Drupal::currentUser()->id(),
        );
  }  

  public static function baseFieldDefinitions(EntityTypeInterface $entity_type) {

    // Standard field, used as unique if primary index.
    $fields['id'] = BaseFieldDefinition::create('integer')
      ->setLabel(t('Invoice #'))
      ->setDescription(t('The ID of the Invoice entity.'))
      ->setReadOnly(TRUE);

    // Standard field, unique outside of the scope of the current project.
    $fields['uuid'] = BaseFieldDefinition::create('uuid')
      ->setLabel(t('UUID'))
      ->setDescription(t('The UUID of the Invoice entity.'))
      ->setReadOnly(TRUE);
	  
    $fields['user_id'] = BaseFieldDefinition::create('entity_reference')
      ->setLabel(t('User Name'))
      ->setDescription(t('The Name of the associated user.'))
	  ->setReadOnly(TRUE);
	  
	$fields['invoice_date'] = BaseFieldDefinition::create('datetime')
      ->setLabel(t('Date'))
      ->setDescription(t('Invoice date'));
	  
	$fields['subject'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Subject'))
      ->setDescription(t('Invoice subject'));
	  
	$fields['company'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Company'))
      ->setDescription(t('Address - Company Name'));

	$fields['name'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Name'))
      ->setDescription(t('Address - Name')); 

	$fields['street'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Street'))
      ->setDescription(t('Address - Street')); 

	$fields['house'] = BaseFieldDefinition::create('string')
      ->setLabel(t('House Number'))
      ->setDescription(t('Address - House Number'));

	$fields['postal'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Postal Code'))
      ->setDescription(t('Address - Postal Code'));

	$fields['city'] = BaseFieldDefinition::create('string')
      ->setLabel(t('City'))
      ->setDescription(t('Address - City'));
   
  $fields['total'] = BaseFieldDefinition::create('string')
    ->setLabel(t('Total'))
    ->setDescription(t('Total'));

  $fields['list_details'] = BaseFieldDefinition::create('string_long')
    ->setLabel(t('List details'))
    ->setDescription(t('List Details'));  
  
  $fields['created'] = BaseFieldDefinition::create('created')
    ->setLabel(t('Created'))
    ->setDescription(t('The time that the entity was created.'));

	$fields['changed'] = BaseFieldDefinition::create('changed')
      ->setLabel(t('Changed'))
	  ->setDescription(t('The time that the entity was last edited.')); 

    return $fields;
  }
}