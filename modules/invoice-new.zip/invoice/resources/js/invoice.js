(function ($, Drupal) {
    Drupal.behaviors.invoice = {
        attach: function (context, settings) {
            $('.datePicker').datepicker({ 
				dateFormat: 'yy-mm-dd', 
			});
			if($('.remove-btn').length){
				$('.remove-btn').on('click', function(event){
					event.preventDefault();
					var row = $(this).data('row');
					var removed_items = $('.removed_items').val();
					if(removed_items != ''){
					    removed_items = removed_items +','+row;
					}else{
					   removed_items = row;
					}
					$('.removed_items').val(String(removed_items));
					$('.list-item-fieldset-'+row).remove();
				});
			}			
        }
    };
    
})(jQuery, Drupal);